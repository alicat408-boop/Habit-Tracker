HABIT TRACKER

This is an installable Progressive Web App (PWA) based on the current August/September version of your habit sheet.

Design goals:
- very quick daily use
- one checkbox per habit
- simple daily score
- simple monthly view
- habit editing only when you choose to use Settings
- no account or remote database
- local-only data storage
- JSON backup and CSV export

Privacy:
Habit entries are stored in your browser on your device. The app has no analytics and sends no habit data to a server. Clearing browser/site data can erase local entries, so export a backup periodically.

Current default habits:
The 15 current habits are preloaded. All 15 current habits, including “Weight down from previous day,” count equally toward the daily score.

To install on a phone:
This PWA must first be hosted on an HTTPS static website. Upload index.html, manifest.webmanifest, sw.js, and icon.svg unchanged to GitHub Pages, Netlify, Cloudflare Pages, or another static host.

iPhone/iPad:
1. Open the hosted site in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Tap Add.

Android:
1. Open the hosted site in Chrome.
2. Open the browser menu.
3. Tap Install app or Add to Home screen.
